
from django.shortcuts import render
from django.http import HttpResponse
from twilio.rest import Client
from twilio.twiml.messaging_response import MessagingResponse
from django.views.decorators.csrf import csrf_exempt
import openai
# from models import Conversation
# Store these in environment variables or some secure place.
TWILIO_ACCOUNT_SID = 'AC94c57dca3ce508f447e239df7a30e235'
TWILIO_AUTH_TOKEN = '1effbbcaa7efbbc71f6e068eb8d0b854'
OPENAI_API_KEY = "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"

def send_message(request):
    client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    message = client.messages.create(
        from_='whatsapp:+14155238886',
        body='Your appointment is coming up on July 21 at 3PM',
        to='whatsapp:+918929766305'
    )
    return HttpResponse("Message sent, SID: " + message.sid)

# def send_messages_from_csv(request):
#     client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    
#     # Path to your CSV file
#     csv_file_path = 'path/to/your/numbers.csv'
    
#     with open(csv_file_path, newline='') as csvfile:
#         reader = csv.reader(csvfile)
#         for row in reader:
#             phone_number = row[0]  # Assuming phone numbers are in the first column
            
#             message = client.messages.create(
#                 from_='whatsapp:+14155238886',
#                 body='Your appointment is coming up on July 21 at 3PM',
#                 to=f'whatsapp:{phone_number}'
#             )
            
#             print(f"Message sent to {phone_number}, SID: {message.sid}")
    
#     return HttpResponse("Messages sent successfully")


from twilio.twiml.messaging_response import MessagingResponse
from django.http import HttpResponse
from openai import OpenAI


from django.db import models
from django.http import HttpResponse
from twilio.twiml.messaging_response import MessagingResponse
from openai import OpenAI
from django.views.decorators.csrf import csrf_exempt
from messaging.models import Conversation,FollowUp



import re
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
from twilio.twiml.messaging_response import MessagingResponse
from .models import Conversation, QualifiedLead  # Import the new model

def qualify_lead(conversation_history, request, user_phone_number):
    # Check if user is already qualified
    if QualifiedLead.objects.filter(phone_number=user_phone_number).exists():
        return False

    user_messages = [msg for msg in conversation_history if msg['role'] == 'user']
    if len(user_messages) > 2:
        request.session['lead_qualified'] = True
        return True

    phone_number_pattern = re.compile(r'\b\d{10}\b')
    if any(phone_number_pattern.search(msg['content']) for msg in user_messages):
        request.session['lead_qualified'] = True
        return True

    hardware_keywords = ['computer', 'RAM', 'SSD', 'CPU', 'Cabinets', 'motherboard',"keyboard","mouse"]
    if any(keyword in msg['content'].lower() for msg in user_messages for keyword in hardware_keywords):
        request.session['lead_qualified'] = True
        return True
    
    if request.session.get('lead_qualified', False):
        print("kokokokokkkoo")
        return False

    return False

@csrf_exempt
def whatsapp_webhook(request):
    conversation_history = request.session.get('conversation_history', [])
    body = request.POST.get('Body', '')
    user_phone_number = request.POST.get('From', '')

    conversation_history.append({"role": "user", "content": body})

    client = OpenAI(api_key=OPENAI_API_KEY)
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=conversation_history,
        max_tokens=250,
    )

    resp = MessagingResponse()

    if response and response.choices and len(response.choices) > 0:
        ai_response = response.choices[0].message.content

        conversation_history.append({"role": "system", "content": ai_response})
        request.session['conversation_history'] = conversation_history

        Conversation.objects.create(user_id=user_phone_number, role="user", content=body, source="whatsapp")
        Conversation.objects.create(user_id=user_phone_number, role="system", content=ai_response, source="gpt-3")

        # Check if the user qualifies as a lead
        if qualify_lead(conversation_history, request, user_phone_number):
            extracted_name, follow_up_time = extract_details(conversation_history)

            resp.message("Thank you for your interest! Our sales team will contact you shortly.")
            
            QualifiedLead.objects.create(
                name=extracted_name,
                phone_number=user_phone_number,
                conversation_summary="\n".join(f"{msg['role']}: {msg['content']}" for msg in conversation_history)
            )
            
            if follow_up_time:
                FollowUp.objects.create(
                    user_phone_number=user_phone_number,
                    follow_up_time=follow_up_time,
                    message=f"Follow up with {extracted_name or 'the user'}"
                )
                
                resp.message(f"We have scheduled a follow-up on {follow_up_time}. Thank you!")

        else:
            resp.message(ai_response)
        
    else:
        resp.message("Sorry, I couldn't understand that.")

    return HttpResponse(resp)

from dateutil.parser import parse as parse_date
import re

def extract_details(conversation_history):
    # Use AI to parse the conversation history for name and follow-up time.
    
    client = OpenAI(api_key=OPENAI_API_KEY)
    
    prompt_texts = [
        {"role": "system", "content": "Extract any name of the user or followup time mentioned in this conversation in json format."},
        *conversation_history
    ]
    
    extraction_response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=prompt_texts,
        max_tokens=100,
    )
     
    extracted_name, follow_up_time = None, None
    
    if extraction_response and extraction_response.choices:
        extraction_content = extraction_response.choices[0].message.content.strip()
        print(extraction_content,"ccccccccccc")  # For debugging purposes
        
        # Assuming the AI returns something like: Name: John Doe; Follow-Up Time: after 6 o'clock
        # Extracting name and follow-up time
        extracted_name = extract_value(extraction_content, "Name")
        follow_up_time = extract_value(extraction_content, "Follow-Up Time")
        
        print(extracted_name, follow_up_time)
        
    
    return extracted_name, follow_up_time

def extract_value(text, key):
    # Function to extract a value associated with a key from a formatted text string
    # Example format assumed: "Name: John Doe; Follow-Up Time: after 6 o'clock"
    
    # Splitting the text into segments based on ';'
    segments = [segment.strip() for segment in text.split(';')]
    print(segments,"oooooooooooooooooooooooooo")
    # Searching for the key and extracting the associated value
    for segment in segments:
        print(segment,"oooooooooooooooooooooooooo")
        if segment.startswith(key + ':'):
            return segment.split(':', 1)[1].strip()
    
    return None


# Example usage with dummy data for `conversation_history`
conversation_history_example = [
    {"role": "user", "content": "Hi there! My name is Yash."},
    {"role": "user", "content": "I'm interested in purchasing an SSD."},
    {"role": "user", "content": "Can we have a call after six o'clock?"}
]

name, time = extract_details(conversation_history_example)
print(f"Extracted Name: {name}")
print(f"Follow-Up Time : {time}")