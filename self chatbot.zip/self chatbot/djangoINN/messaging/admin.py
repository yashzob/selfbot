
from django.contrib import admin
from .models import Conversation,QualifiedLead,FollowUp

admin.site.register(Conversation)
admin.site.register(QualifiedLead)
admin.site.register(FollowUp)
#