from django.db import models

from django.db import models

class Conversation(models.Model):
    role_choices = (
        ('user', 'User'),
        ('system', 'System'),
    )

    user_id = models.CharField(max_length=255)
    role = models.CharField(max_length=50, choices=role_choices)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    source = models.CharField(max_length=100, blank=True, null=True)
    confidence = models.FloatField(blank=True, null=True)

    def __str__(self):
        return f"{self.role} - {self.content}"
    
from django.db import models

class QualifiedLead(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    name = models.CharField(max_length=255, blank=True, null=True)  # Optional field
    
    phone_number = models.CharField(max_length=20)  # Add this line to store phone numbers
    conversation_summary = models.TextField()

from django.db import models

class FollowUp(models.Model):
    user_phone_number = models.CharField(max_length=15)
    follow_up_time = models.DateTimeField()
    message = models.TextField()

    def __str__(self):
        return f"Follow up with {self.user_phone_number} at {self.follow_up_time}"