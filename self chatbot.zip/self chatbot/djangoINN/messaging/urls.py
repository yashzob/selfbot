from django.urls import path
from . import views

urlpatterns = [
    path('send-message/', views.send_message, name='send-message'),
    path('whatsapp-webhook/', views.whatsapp_webhook, name='whatsapp-webhook'),
]